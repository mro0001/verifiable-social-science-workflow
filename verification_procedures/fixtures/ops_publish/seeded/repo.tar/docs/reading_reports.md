# Reading the reports

Each report sits beside its results file, under project/verification/<product>/<stream>/.

## What each report found

| Prose | Count |
|---|---|
| Changes | 9 |
| Made by an AI | 5 |
| With no reason on record | 3 |

| References | Count |
|---|---|
| Citations | 7 |
| First named by an AI | 5 |
| No quote found in the source | 1 |

# Verification reports for a test paper

AI sessions helped write paper and slides. The workflow found each AI contribution, checked it, and wrote a report for the scholar. No model gives a verdict in any report. The scholar approves or holds each item. 3 items are approved, 1 held, and 30 not yet decided.

![Prose: 5 of 7 changes by an AI. References: 5 of 7 citations named by an AI. Data: 2 of 3 numbers reproduce. Build: 3 problems.](docs/results.svg)

| Stream | What the check found | Reports |
|---|---|---|
| Prose | 5 of 8 changes were made by an AI. Each is shown with the reason the AI gave, and 3 have none on record. | [paper](project/verification/paper/prose/report.md) · [slides](project/verification/slides/prose/report.md) |
| References | 5 of 7 citations were first named by an AI. For 1 of them, no quote was found in the source. 1 cited work was not found. | [paper](project/verification/paper/citations/report.md) |
| Data and analysis code | AI sessions wrote or changed 2 of the 3 analysis scripts. 2 of the 3 numbers reproduce from the raw data. | [paper](project/verification/paper/data/report.md) |
| Build | Each document has one source. AI sessions wrote to a build folder 1 time. The report flags 3 problems for the scholar, 2 of them from the check for results typed into the text. | [paper](project/verification/paper/build/report.md) · [slides](project/verification/slides/build/results.json) |

## Try it

```
git clone https://git.example.org/scholar/workflow.git
git clone https://git.example.org/scholar/test-paper.git
cd test-paper/project
SOURCE_DATE_EPOCH=1792022400 make paper
```

Each command builds the product again as its next numbered build. slides has no numbered build yet.

## Read more

- [Reading the reports](docs/reading_reports.md)
- [The record](docs/record.md)
- [Rebuilding](docs/rebuild.md)
- [The session index](project/sessions/index.html)

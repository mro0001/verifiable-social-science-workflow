# The prose report for paper

## Summary

- Items: listed in results.json.

Run folder: -Users-jdoe-Documents-paper-runs-x

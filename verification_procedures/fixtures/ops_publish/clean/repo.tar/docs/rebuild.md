# Rebuilding

The build needs Python 3.9 or later, PyYAML, python-docx, pandoc, make, and the workflow cloned beside this repository.

```
cd project
SOURCE_DATE_EPOCH=1792022400 make paper
```

# The record

The transcripts stay private. The index names each session by its public id, S and 12 characters of a checksum. The index lists 3 sessions, 2 of which contributed, with 5 contributions.

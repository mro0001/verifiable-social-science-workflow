# A test paper

The mean is {{num:results.mean}} over {{num:results.count}} cases [@smith2020]. Earlier work found the same [@lee2019; @park2021].

The share is {{num:results.share}} [@kim2018; @ross2017].

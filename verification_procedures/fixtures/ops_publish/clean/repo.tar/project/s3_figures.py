"""Step 3 of the pipeline."""
print("step 3")

# The citations report for paper

## Summary

- Items: listed in results.json.

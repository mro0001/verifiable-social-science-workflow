# The project

| Entry | What it is |
|---|---|
| Makefile | The build file, one rule per research product |
| manuscript.md | The source text of paper |
| slides.md | The source text of slides |
| builds/ | Every numbered build, with its ledger BUILDS.md |
| verification/ | Each report, report.md, and its results file, results.json, by product |
| sessions/ | The public index of the AI sessions behind the reports |

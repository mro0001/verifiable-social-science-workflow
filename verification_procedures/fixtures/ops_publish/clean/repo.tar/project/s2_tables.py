"""Step 2 of the pipeline."""
print("step 2")

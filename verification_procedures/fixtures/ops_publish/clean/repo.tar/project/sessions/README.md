# The session index

Each row of sessions.csv is one AI session, named by its public id. The transcripts stay private.

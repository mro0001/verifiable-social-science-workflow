"""Step 1 of the pipeline."""
print("step 1")

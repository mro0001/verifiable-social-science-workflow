# Builds

| version | date | git | sha256 | purpose | baseline | reviewed | verification | runs |
|---|---|---|---|---|---|---|---|---|
| v001 | 2026-10-01 | - | 6b63dacae6e8a9f53fd18339f7e8bd464f25b5c79bbf1d6d986013fdfedbffd5 | first draft | - | no | unverified: prose, citations, data, build | - |
| v002 | 2026-10-15 | - | a096dea32cf36205508beeb0fa8c74ba21ed83a84cbc2eac10c4833c7ace79e0 | draft | - | no | unverified: prose, citations, data, build | prose=paper_prose; citations=paper_citations; data=paper_data; build=paper_build |

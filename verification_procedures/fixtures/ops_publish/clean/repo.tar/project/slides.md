# Slides

- The mean is {{num:results.mean}}.
